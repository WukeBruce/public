#!/bin/bash
# ./configure --help

CUR_PREFIX=`pwd`

./configure --prefix=$CUR_PREFIX/../../library/

#./configure --prefix=$HOME/sdl/lib_sdl CPPFLAGS=-I$HOME/sdl/lib_sdl/include LDFLAGS=-L$HOME/sdl/lib_sdl/lib
