#!/bin/bash
# ./configure --help

#./configure --prefix=$HOME/sdl/lib_sdl
CUR_PREFIX=`pwd`
./configure --prefix=$CUR_PREFIX/../../library/ --enable-freetype-config
#./configure --prefix=$CUR_PREFIX/../../library/ CPPFLAGS=-I$CUR_PREFIX/../../library/include LDFLAGS=-L$CUR_PREFIX/../../library//lib
